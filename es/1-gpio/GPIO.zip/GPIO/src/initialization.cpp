#include "initialization.h"

void GPIOx_Init(void)
{
    // Enable GPIOB and GPIOC clocks
    RCC->AHBENR |= RCC_AHBENR_GPIOBEN | RCC_AHBENR_GPIOCEN;

    // Configure PB3 (Red), PB4 (Green), PB5 (Blue) as output
    GPIOB->MODER &= ~((0x3 << (RED_PIN * 2)) | (0x3 << (GREEN_PIN * 2)) | (0x3 << (BLUE_PIN * 2))); // Reset bits
    GPIOB->MODER |= ((0x1 << (RED_PIN * 2)) | (0x1 << (GREEN_PIN * 2)) | (0x1 << (BLUE_PIN * 2)));  // Set as general-purpose output

    // Configure PC13 (Button) as input
    //GPIOC->MODER &= ~(0x3 << (BUTTON_PIN * 2));  // Set PC13 as input mode

    //THIS IS NOT TESTED - change game -> in the getPlayerInput function change the if statement to check for a high value instead of a low value
    // Configure PC13 Button to use pull-down resistor
    // GPIOC->PUPDR &= ~(0x3 << (BUTTON_PIN * 2));  // Clear the existing configuration
    // GPIOC->PUPDR |= (0x2 << (BUTTON_PIN * 2));   // Set PC13 as pull-down
}   

// Configure the system clock to 72 MHz. This means the APB1 peripheral clock and also the USART2 will be clocked at 36 MHz.
void SystemClock_Config(void)
{
    // Configure Flash latency for 48 < HCLK ≤ 72 MHz, see datasheet. Do this before setting the system clock to 72 MHz.
    FLASH->ACR &= ~FLASH_ACR_LATENCY;
    FLASH->ACR |= FLASH_ACR_LATENCY_2;

    // Enable the HSI (internal high-speed) oscillator
    RCC->CR |= RCC_CR_HSION;
    while (!(RCC->CR & RCC_CR_HSIRDY))
        ; // Wait until HSI is ready

    // Set the APB1 prescaler to 2
    RCC->CFGR &= ~RCC_CFGR_PPRE1;
    RCC->CFGR |= RCC_CFGR_PPRE1_DIV2;

    // Set the PLL SRC to HSI and PREDIV to /1
    RCC->CFGR &= ~RCC_CFGR_PLLSRC;
    RCC->CFGR |= RCC_CFGR_PLLSRC_HSI_PREDIV;

    // Set PLL multiplier to 9 (8 MHz * 9 = 72 MHz)
    RCC->CFGR &= ~RCC_CFGR_PLLMUL;
    RCC->CFGR |= RCC_CFGR_PLLMUL9;

    // Enable the PLL
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY))
        ; // Wait until PLL is ready

    // Select PLL as system clock source
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL)
        ; // Wait until PLL becomes the system clock

    // Update the system core clock variable
    SystemCoreClockUpdate();
}
